<?php include('header.php'); ?>
<body>
<?php include('navbar.php'); ?>
<?php 
if ( !empty( $_POST[ 'username' ] ) || !empty( $_POST[ 'password' ] ) ) {
    if ( isset( $_POST[ 'username' ] ) && isset( $_POST[ 'password' ] ) ) {
        $stmt = $pdo->prepare( 'SELECT * FROM users WHERE username=:username AND password=:password' );
        $stmt->bindValue( 'username', $_POST[ 'username' ] );
        $stmt->bindValue( 'password', $_POST[ 'password' ] );
        $stmt->execute();
        
        $user = $stmt->fetch();
        if ( $user ) {
            $_SESSION[ 'user' ] = $user;}
    }
}
?>
<div class="container">
	<h1 class="page-header text-center">Login</h1>
            <form method="post">
                <div class="form-row text-center">
                    <div class="form-group">
                        <input name="username" type="text" class="login-style input-width" id="username" placeholder="Username" maxlength="50">
                    </div>
                    <div class="form-group text-center">
                        <input type="password" class="login-style input-width" id="password" placeholder="Password" maxlength="50" name="password">
                    </div>
                    <div class="form-group pl-2 text-center"><input class="btn btn-primary submit-width" type="submit" value=Login></div>
                    <?php if (isset( $_SESSION[ 'user' ] ) ) {
                    echo("<script>location.href = 'index.php';</script>");
                    }
                    ?>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
<?php include('footer.php'); ?>
</html>