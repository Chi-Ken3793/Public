<?php include('header.php'); ?>
<?php if ( !isset( $_SESSION[ 'user' ] ) ) {
header( 'Location: index.php' );
exit();
}else{ ?>
<body>
<?php include('navbar.php'); ?>
<div class="container">
	<h1 class="page-header text-center">Salg</h1>
	<table class="table table-striped table-bordered">
		<thead>
			<th>Dato</th>
			<th>Kunde</th>
			<th>Totalt</th>
			<th>Detaljer</th>
		</thead>
		<tbody>
			<?php 
				$sql="select * from purchase order by purchaseid desc";
				$query=$conn->query($sql);
				while($row=$query->fetch_array()){
					?>
					<tr>
						<td><?php echo date('M d, Y h:i A', strtotime($row['date_purchase'])) ?></td>
						<td><?php echo $row['customer']; ?></td>
						<td class="text-right"><?php echo number_format($row['total'], 2); ?> dkk</td>
						<td><a href="#details<?php echo $row['purchaseid']; ?>" data-toggle="modal" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-search"></span> Vis </a>
							<?php include('sales_modal.php'); ?>
						</td>
					</tr>
					<?php
				}
			?>
		</tbody>
	</table>
</div>
<?php include('footer.php'); ?>
</body>
</html>
<?php } ?>