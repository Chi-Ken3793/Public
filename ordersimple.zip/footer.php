<footer>
    <center>Tak til Neovic | Bragt til dig af <a href="https://code-projects.org/simple-food-ordering-system-in-php-with-source-code/">code-projects.org</a></center>
    <center>Dette websted bruger bootstrap. <a href="https://getbootstrap.com/">getbootstrap.com</a></center>
</footer>