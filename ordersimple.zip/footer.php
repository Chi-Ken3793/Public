<footer>
    <div class="container text-center">
        <div class="row">Dette websted er kun til studie brug.</div>
        <div class="row">Tak til Neovic | Bragt til dig af <a href="https://code-projects.org/simple-food-ordering-system-in-php-with-source-code/">code-projects.org</a></div>
        <div class="row">Dette websted bruger bootstrap. <a href="https://getbootstrap.com/">getbootstrap.com</a></div>
    </div>
</footer>
