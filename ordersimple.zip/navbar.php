<nav class="navbar navbar-main navbar-default">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Skift navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php"><b>EAMV Kantine</b></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="col-7 collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a class="navbar-link" href="order.php">Ordre</a></li>
        <?php 
          if ( !isset( $_SESSION[ 'user' ] ) ) { 
          ?>
          <li><a class="navbar-link" href="login.php">Login</a></li>
        <?php }
          
          else if ( isset( $_SESSION[ 'user' ] ) ) {
         ?>
        <li><a class="navbar-link" href="sales.php">Salg</a></li>
        <li>
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Vedligeholdelse <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a class="navbar-link" href="product.php">Produkter</a></li>
            <li><a class="navbar-link" href="category.php">Kategori</a></li>
          </ul>
        </li>
          <li><a class="navbar-link" href="logout.php">Logud</a></li>
          <?php } ?>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>